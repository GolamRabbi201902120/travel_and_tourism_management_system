package com.example.travel__tourism_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class military_musuem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_military_musuem);
    }
}