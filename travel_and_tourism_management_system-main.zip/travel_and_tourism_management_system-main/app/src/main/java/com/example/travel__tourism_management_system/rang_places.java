package com.example.travel__tourism_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class rang_places extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rang_places);
    }
}